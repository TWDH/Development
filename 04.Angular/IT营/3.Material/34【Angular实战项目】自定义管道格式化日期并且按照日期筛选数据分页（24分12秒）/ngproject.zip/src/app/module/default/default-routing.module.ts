import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DefaultComponent } from './default.component';
import { HomeComponent } from './component/home/home.component';
import { ReportComponent } from './component/report/report.component';
import { KeywordsComponent } from './component/keywords/keywords.component';
import { AlarmComponent } from './component/alarm/alarm.component';
import { PositiveReportComponent } from './component/positive-report/positive-report.component';
import { NegativeReportComponent } from './component/negative-report/negative-report.component';

import {LoginGuard } from '../../service/login.guard';
const routes: Routes = [
  {
    path:"",
    component:DefaultComponent,
    canActivate:[LoginGuard],
    children:[
      {
        path:"home",
        component:HomeComponent,
        canActivate:[LoginGuard],
      },
      {
        path:"negativeReport",
        component:NegativeReportComponent,
        canActivate:[LoginGuard],
      },
      {
        path:"positiveReport",
        component:PositiveReportComponent,
        canActivate:[LoginGuard],
      },
      {
        path:"report",
        component:ReportComponent,
        canActivate:[LoginGuard],
      },
      {
        path:"keywords",
        component:KeywordsComponent,
        canActivate:[LoginGuard],
      },
      {
        path:"alarm",
        component:AlarmComponent,
        canActivate:[LoginGuard],
      }
    ]
  }

];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DefaultRoutingModule { }
