import { Component, OnInit } from '@angular/core';
import { HttpService } from '../../../../service/http.service';
import { StorageService } from '../../../../service/storage.service';
import { NzMessageService } from 'ng-zorro-antd/message';
@Component({
  selector: 'app-alarm',
  templateUrl: './alarm.component.html',
  styleUrls: ['./alarm.component.scss']
})
export class AlarmComponent implements OnInit {
  userinfo: any;
  alarm = {
    tel: "",
    email: ""
  }
  constructor(private http: HttpService, private storage: StorageService, private message: NzMessageService) {
    this.userinfo = this.storage.get("userinfo");
  }
  ngOnInit(): void {
    this.getAlarm();
  }
  //弹出提示信息 success  error
  createMessage(type: string, msg: string): void {
    this.message.create(type, msg);
  }
  //获取报警设置
  getAlarm() {
    var api = "/api/alarmList";
    this.http.get(api, {
      auth: {
        username: this.userinfo.token,
        password: ''
      }
    }).then((response: any) => {
      console.log(response);
      if (response.data.success == true) {
        this.alarm.tel = response.data.result.tel;
        this.alarm.email = response.data.result.email;
      }
    })
  }
  //修改设置
  setAlarm() {
    var api = "/api/editAlarm";
    this.http.post(api, this.alarm, {
      auth: {
        username: this.userinfo.token,
        password: ''
      }
    }).then((response: any) => {
      console.log(response);
      if (response.data.success == true) {
        this.createMessage("success","修改设置成功");
      }else{
        this.createMessage("error","修改设置失败");
      }
    })
  }


}
