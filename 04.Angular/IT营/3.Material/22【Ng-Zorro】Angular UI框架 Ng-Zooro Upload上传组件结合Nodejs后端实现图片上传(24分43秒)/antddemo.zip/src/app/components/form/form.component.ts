import { Component, OnInit } from '@angular/core';
import { NzUploadFile } from 'ng-zorro-antd/upload';
import { Observable, Observer } from 'rxjs';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {

  public loading = false;
  public avatarUrl?: string;

  public inputData={
    username:"",
    age:"",
    sex:"女",
    hobby : [
      { label: '吃饭', value: '吃饭', checked: true },
      { label: '睡觉', value: '睡觉',checked: true },
      { label: '写代码', value: '写代码' }
    ],
    vip:"vip2",
    datetime:new Date(),
    picUrl:""
  }
  constructor() { }

  ngOnInit(): void {
  }

  doSubmit(): void {
    console.log(this.inputData)

    var d=new Date(this.inputData.datetime);
    console.log(d.getTime());  //获取时间戳
  }

  //上传之前触发的方法 主要作用就是判断文件类型 判断文件大小
  beforeUpload = (file: NzUploadFile, _fileList: NzUploadFile[]) => {
    return new Observable((observer: Observer<boolean>) => {
      const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';

      if (!isJpgOrPng) {
        console.log('You can only upload JPG file!');
        observer.complete();
        return;
      }
      const isLt2M = file.size! / 1024 / 1024 < 2;
      if (!isLt2M) {
         console.log('Image must smaller than 2MB!');
        observer.complete();
        return;
      }
      observer.next(isJpgOrPng && isLt2M);
      observer.complete();
    });
  };

  private getBase64(img: File, callback: (img: string) => void): void {
    const reader = new FileReader();
    reader.addEventListener('load', () => callback(reader.result!.toString()));
    reader.readAsDataURL(img);
  }

  handleChange(info: { file: NzUploadFile }): void {
    switch (info.file.status) {
      case 'uploading':
        this.loading = true;
        break;
      case 'done':
        console.log(info.file.response);
        this.inputData.picUrl=info.file.response.url;
        // Get this url from response in real world.
        this.getBase64(info.file!.originFileObj!, (img: string) => {
          this.loading = false;
          this.avatarUrl = img;
        });
        break;
      case 'error':
        console.log('Network error');
        this.loading = false;
        break;
    }
  }


}
