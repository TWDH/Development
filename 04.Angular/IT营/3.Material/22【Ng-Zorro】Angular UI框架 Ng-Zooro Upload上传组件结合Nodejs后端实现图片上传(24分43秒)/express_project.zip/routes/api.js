const express = require("express");

var router = express.Router()

var tools = require("../model/tools")

router.get("/", (req, res) => {
  res.send("api接口")
})

//http://localhost:3000/api/ngUpload
router.post("/ngUpload", tools.multer().single("avatar"), (req, res) => {  //获取表单传过来的数据    
  console.log(req.file);
  
  res.send({
    url: req.file.path,
  })
})

module.exports = router