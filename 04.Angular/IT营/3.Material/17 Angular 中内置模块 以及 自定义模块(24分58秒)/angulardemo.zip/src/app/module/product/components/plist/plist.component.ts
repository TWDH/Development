import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plist',
  templateUrl: './plist.component.html',
  styleUrls: ['./plist.component.scss']
})
export class PlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
