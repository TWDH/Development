import { FormattimePipe } from './formattime.pipe';

describe('FormattimePipe', () => {
  it('create an instance', () => {
    const pipe = new FormattimePipe();
    expect(pipe).toBeTruthy();
  });
});
