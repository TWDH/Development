import { Component, OnInit } from '@angular/core';
import { HttpService } from '../../service/http.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private http:HttpService,private router:Router) { }
  captchaData={
    svgImg:""   
  }
  loginData={
    username:"",
    password:"",
    verify:"",
    svgKey:""
  }
  ngOnInit(): void {
   
  }
  ngAfterContentInit(){
    this.getCaptcha();
  }
  getCaptcha(){
    // http://yuqing.itying.com/api/captcha

    var api="http://yuqing.itying.com/api/captcha";
    this.http.get(api).then((response:any)=>{
        console.log(response);
        this.captchaData.svgImg=response.data.svgImg;
        this.loginData.svgKey=response.data.svgKey

        var svgImgDom=document.querySelector("#svgImg");       
        svgImgDom.innerHTML=this.captchaData.svgImg;
    })
  }
  //执行登录的方法
  doLogin(){
    // console.log(this.loginData);
    var api="http://yuqing.itying.com/api/doLogin";
    this.http.post(api,this.loginData).then((response:any)=>{
        console.log(response);          
        if(response.data.success){
          this.router.navigate(['/default']);
        }else{
          alert(response.data.message)
        }
    })
  }

}
