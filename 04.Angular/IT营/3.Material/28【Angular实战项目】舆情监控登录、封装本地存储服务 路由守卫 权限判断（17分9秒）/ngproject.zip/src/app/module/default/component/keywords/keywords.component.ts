import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-keywords',
  templateUrl: './keywords.component.html',
  styleUrls: ['./keywords.component.scss']
})
export class KeywordsComponent implements OnInit {

  isVisible=false;
  isOkLoading = false;
  inputData={
    keyword:"",
    may_keyword:"",
    nokeyword:"",
    frequency:""
  }
  listData = [
    {
      keyword: '大庆油田',
      may_keyword: '中国石油',
      nokeyword: "延长石油",
      frequency: '100'
    },
    {
      keyword: '数字人民币',
      may_keyword: 'dec',
      nokeyword: "",
      frequency: '100'
    },
  ];
  constructor() { }

  ngOnInit(): void {
  }

  showModel(){
 
    this.isVisible=true;
  }
  handleCancel(){
    console.log("取消");
    this.isVisible = false;
  }
  handleOk(){
    console.log("确定")
    this.isOkLoading = true;
    setTimeout(() => {
      this.isVisible = false;
      this.isOkLoading = false;
    }, 2000);
  }

}
