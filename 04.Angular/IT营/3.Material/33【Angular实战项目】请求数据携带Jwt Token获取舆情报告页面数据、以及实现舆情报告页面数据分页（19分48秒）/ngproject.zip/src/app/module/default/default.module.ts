import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DefaultRoutingModule } from './default-routing.module';
import { DefaultComponent } from './default.component';
import { HomeComponent } from './component/home/home.component';
import { ReportComponent } from './component/report/report.component';
import { KeywordsComponent } from './component/keywords/keywords.component';
import { AlarmComponent } from './component/alarm/alarm.component';

//antd对应的模块
import { NZ_I18N } from 'ng-zorro-antd/i18n';
import { zh_CN } from 'ng-zorro-antd/i18n';
import { registerLocaleData } from '@angular/common';
import zh from '@angular/common/locales/zh';
//用到双休数据绑定必须引入
import { FormsModule } from '@angular/forms';

//图标按钮模块
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzIconModule } from 'ng-zorro-antd/icon';
//布局组件需要引入的模块
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzBreadCrumbModule } from 'ng-zorro-antd/breadcrumb';

//highcharts模块
import { HighchartsChartModule } from 'highcharts-angular';

//日期模块
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';

//表格模块
import { NzTableModule } from 'ng-zorro-antd/table';

//对话框
import { NzModalModule } from 'ng-zorro-antd/modal';

//表单
import { NzInputModule } from 'ng-zorro-antd/input';

//提示

import { NzMessageModule } from 'ng-zorro-antd/message';


registerLocaleData(zh);

@NgModule({
  declarations: [DefaultComponent, HomeComponent, ReportComponent, KeywordsComponent, AlarmComponent],
  imports: [
    CommonModule,
    DefaultRoutingModule,
    NzButtonModule,
    NzIconModule,
    NzLayoutModule,
    NzMenuModule,
    NzBreadCrumbModule,
    HighchartsChartModule,
    NzDatePickerModule,
    FormsModule,
    NzTableModule,
    NzModalModule,
    NzInputModule,
    NzMessageModule
  ],
  providers: [{ provide: NZ_I18N, useValue: zh_CN }],
})
export class DefaultModule { }
