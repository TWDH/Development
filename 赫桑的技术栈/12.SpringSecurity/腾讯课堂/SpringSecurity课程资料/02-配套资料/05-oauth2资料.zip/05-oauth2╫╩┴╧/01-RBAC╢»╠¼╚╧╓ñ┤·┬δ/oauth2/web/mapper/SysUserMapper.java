package com.mengxuegu.oauth2.web.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mengxuegu.oauth2.web.entities.SysUser;

/**
 * @Auther: 梦学谷 www.mengxuegu.com 
 */
public interface SysUserMapper extends BaseMapper<SysUser> {
}