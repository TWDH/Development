import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {

  public inputData={
    username:"",
    age:"",
    sex:"女",
    hobby : [
      { label: '吃饭', value: '吃饭', checked: true },
      { label: '睡觉', value: '睡觉',checked: true },
      { label: '写代码', value: '写代码' }
    ],
    vip:"vip2",
    datetime:new Date()
  }
  constructor() { }

  ngOnInit(): void {
  }

  doSubmit(): void {
    console.log(this.inputData)

    var d=new Date(this.inputData.datetime);
    console.log(d.getTime());  //获取时间戳
  }

}
