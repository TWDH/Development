import { Component, OnInit } from '@angular/core';
import { HttpService } from '../../../../service/http.service';
import { StorageService } from '../../../../service/storage.service';
@Component({
  selector: 'app-keywords',
  templateUrl: './keywords.component.html',
  styleUrls: ['./keywords.component.scss']
})
export class KeywordsComponent implements OnInit {

  isAddVisible = false;
  isOkAddLoading = false;
  isEditVisible = false;
  isOkEditLoading = false;

  userinfo: any;
  inputAddData = {
    keyword: "",
    may_keyword: "",
    nokeyword: "",
    frequency: ""
  }
  inputEditData = {
    id:"",
    keyword: "",
    may_keyword: "",
    nokeyword: "",
    frequency: ""
  }
  listData: any[];
  constructor(private http: HttpService, private storage: StorageService) {

    this.userinfo = this.storage.get("userinfo");
    // console.log(this.userinfo);
  }

  ngOnInit(): void {
    this.getKeywords();
  }

  showModel() {
    this.isAddVisible = true;
  }
  //公共取消
  handleCancel() {
    console.log("取消");
    this.isAddVisible = false;
    this.isEditVisible=false;
  }
  //增加舆情
  handleAdd() {

    this.isOkAddLoading = true;
    var api = "/api/addKeywords";
    this.http.post(api, this.inputAddData, {
      auth: {
        username: this.userinfo.token,
        password: ''
      }
    }).then((response: any) => {
      this.getKeywords();
      this.isAddVisible = false;
      this.isOkAddLoading = false;
    })
  }

  //获取舆情关键词
  getKeywords() {
    var api = "/api/keywordsList";

    this.http.get(api, {
      auth: {
        username: this.userinfo.token,
        password: ''
      }
    }).then((response: any) => {
      console.log(response);
      if (response.data.success == true) {
        this.listData = response.data.result;
      }
    })
  }
  //获取要修改的关键词
  showEditModal(id) {
      this.isEditVisible=true;
   
      var api="/api/oneKeywordsList?id="+id;
      this.http.get(api, {
        auth: {
          username: this.userinfo.token,
          password: ''
        }
      }).then((response: any) => {
        console.log(response);     
        this.inputEditData=  response.data.result;
      })


  }
  //执行修改
  handleEdit(){    
    this.isOkEditLoading = true;
    var api="/api/editKeywords";
    this.http.post(api, this.inputEditData, {
      auth: {
        username: this.userinfo.token,
        password: ''
      }
    }).then((response: any) => {
      this.getKeywords();
      this.isEditVisible = false;
      this.isOkEditLoading = false;
    })
  }
  //删除关键词
  deleteKeywords(id) {

    var flag=confirm("您确定要删除吗?");
    if (flag){
      var api="/api/deleteKeywords?id="+id;
      this.http.get(api, {
        auth: {
          username: this.userinfo.token,
          password: ''
        }
      }).then((response: any) => {
        console.log(response)
        if(response.data.success==false){
          alert(response.data.message)
        }
        this.getKeywords();
      })

    }
  }


}
