import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pcontent',
  templateUrl: './pcontent.component.html',
  styleUrls: ['./pcontent.component.scss']
})
export class PcontentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
