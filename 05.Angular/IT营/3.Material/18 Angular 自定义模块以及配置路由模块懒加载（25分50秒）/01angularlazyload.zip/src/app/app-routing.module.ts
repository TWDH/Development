import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
/*
注意：Angular10.x中配置懒加载有一些区别

Angular10.x之前
{
  path:'user',loadChildren:'./module/user/user.module#UserModule'   
}

Angular10.x之后
  {
    path:'user',
    loadChildren: () => import('./module/user/user.module').then(m => m.UserModule)
  }
*/

const routes: Routes = [
  {
 
    path:'user',
    loadChildren: () => import('./module/user/user.module').then(m => m.UserModule)
  },
  {

    path:'article',

    loadChildren: () => import('./module/article/article.module').then(m => m.ArticleModule)
  },
  {

    path:'product',
    loadChildren: () => import('./module/product/product.module').then(m => m.ProductModule)
  },

  {

    path:'**',redirectTo:'user'
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
