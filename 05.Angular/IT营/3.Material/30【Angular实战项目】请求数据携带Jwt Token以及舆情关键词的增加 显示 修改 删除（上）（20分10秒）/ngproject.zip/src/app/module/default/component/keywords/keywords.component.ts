import { Component, OnInit } from '@angular/core';
import { HttpService } from '../../../../service/http.service';
import { StorageService } from '../../../../service/storage.service';
@Component({
  selector: 'app-keywords',
  templateUrl: './keywords.component.html',
  styleUrls: ['./keywords.component.scss']
})
export class KeywordsComponent implements OnInit {

  isVisible=false;
  isOkLoading = false;
  userinfo:any;
  inputAddData={
    keyword:"",
    may_keyword:"",
    nokeyword:"",
    frequency:""
  }
  listData:any[];
  constructor(private http:HttpService,private storage:StorageService) { 

    this.userinfo=this.storage.get("userinfo");
    // console.log(this.userinfo);
  }

  ngOnInit(): void {
    this.getKeywords();
  }

  showModel(){ 
    this.isVisible=true;
  }
  //取消
  handleCancel(){
    console.log("取消");
    this.isVisible = false;
  }
  //增加舆情
  handleAdd(){
    
    this.isOkLoading = true;
    var api="/api/addKeywords";
    this.http.post(api,this.inputAddData,{
      auth: {
        username: this.userinfo.token,
        password: ''
      }
    }).then((response:any)=>{
        this.getKeywords();
        this.isVisible = false;
        this.isOkLoading = false;
    })
  }

  //获取舆情关键词
  getKeywords(){
    var api="/api/keywordsList";

    this.http.get(api,{
      auth: {
        username: this.userinfo.token,
        password: ''
      }
    }).then((response:any)=>{
      console.log(response);
      if(response.data.success==true)
      {
        this.listData=response.data.result;
      }
    })
  }

}
